% Defines the constants used

load('trial_3.mat')
% [rgb, depth] = myGrabKinect();
if ~(size(rgb,1) == size(depth,1) && size(rgb,2) == size(depth,2))
    error('depth and RGB do not match');
end

% Vertical and horizontal field of views
PARAMS.VERT_RGB_FOV = 43.5 / 360 * 2 * pi; % 43.5 degrees
PARAMS.HORIZ_RGB_FOV = 57.5 / 360 * 2 * pi; % 57.5 degrees

% Estimated Kinect sensor angle
PARAMS.SENSOR_ANGLE_DEG = 20; % 20 degrees downward

% Too high? -> Less accurate result!
% Too low? -> Slow computation.
% Should be an int > 0.
PARAMS.GROUND_PLANE_DECIMATION_FACTOR = 103;

% Too high? -> Obstacles can be considered ground.
% Too low? -> Fit more vulnerable to noise.
% Should be an int > 2. Dependent on GROUND_PLANE_DECIMATION_FACTOR.
PARAMS.GROUND_PLANE_POINT_THRESHOLD = 500;

% Occupancy grid parameters
PARAMS.XY_RESOLUTION = 5/100; % 5 cm
PARAMS.ROBOT_HEIGHT = 40/100; % 40 cm
PARAMS.GROUND_HEIGHT = 5/100; % 5 cm