% Main camera calibration toolbox:
format compact
